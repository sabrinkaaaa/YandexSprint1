from flask import Flask, request, jsonify
import random

app = Flask(__name__)

@app.route('/temperature')
def temp():
    loc = request.args.get('location', 'unknown')
    value = round(random.uniform(-10, 35), 1)
    return jsonify({"location": loc, "temperature": value})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8081)
